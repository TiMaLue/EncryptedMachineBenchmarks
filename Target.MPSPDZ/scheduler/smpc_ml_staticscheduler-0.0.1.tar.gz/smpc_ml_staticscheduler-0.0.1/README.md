# SMPC_ML_StaticScheduler
A static scheduler to optimize neural network inference run in the SMPC framework MP-SPDZ.