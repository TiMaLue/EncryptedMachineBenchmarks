from typing import List
from torchvision.models import mobilenetv3
from torch import nn


def find_hardswish_recursive(
    parent: nn.Module, indexstring: str, all_id_strings: List[str], debug: bool = False
):
    children = parent.children()
    for m_id, module in enumerate(children):
        # print(f'Module: {module}')
        try:
            next(module.children())
            if type(parent) == mobilenetv3.InvertedResidual:
                new_indexstring = ".".join([indexstring, "block"])
            else:
                new_indexstring = f"{indexstring}[{m_id}]"
            find_hardswish_recursive(
                module, new_indexstring, all_id_strings, debug=debug
            )
        except StopIteration:
            if type(module) == nn.Hardswish:
                new_indexstring = f"{indexstring}[{m_id}]"
                all_id_strings.append(new_indexstring)
            elif debug:
                all_id_strings.append(f"No Hardswish for {indexstring}.{m_id}")
    return all_id_strings


def get_hardswish_paths(net: nn.Module):
    paths = []
    for f_id, feature in enumerate(net.features):
        # print(f_id, '->', f)
        all_id_strings = []
        indexstring = str([f_id])
        if type(feature) == nn.Hardswish:
            all_id_strings.append(indexstring)
        if next(feature.children()) != None:
            all_id_strings = find_hardswish_recursive(
                feature, indexstring, all_id_strings, debug=False
            )
        # print(all_id_strings)
        paths.extend(all_id_strings)
    print(f"Paths of layers to replace: {paths}")
    print(f"Num layers to replace: {len(paths)}")
    return paths


def replace_hardswish_layers(net: nn.Module, target_layer: nn.Module):
    paths = get_hardswish_paths(net)
    for path in paths:
        exec(f"net.features{path} = {target_layer}")
