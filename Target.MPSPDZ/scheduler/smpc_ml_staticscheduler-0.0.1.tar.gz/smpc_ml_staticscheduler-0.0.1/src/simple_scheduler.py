import configparser


def schedule_runs(config_path: str):
    config = configparser.ConfigParser()
    config.read(config_path)
    scheduled_params = {}
    scheduler_config = config["Scheduler"]
    for dataset_size in scheduler_config["DatasetSize"]:
        scheduled_params["dataset_size"] = dataset_size
        for batch_size in scheduler_config["BatchSize"]:
            scheduled_params["batch_size"] = batch_size
            print(scheduled_params)


if __name__ == "__main__":
    schedule_runs("../config.toml")
