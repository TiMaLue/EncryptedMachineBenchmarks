import json
import time
import subprocess
import copy


def schedule_runs(config_path: str, input_fp: str, dry_run: bool = False):
    scheduled_params = {}
    with open(config_path, "r") as fp:
        scheduler_config = json.load(fp)
    for dataset_size in scheduler_config["dataset_size"]:
        scheduled_params["dataset_size"] = dataset_size
        for batch_size in scheduler_config["batch_size"]:
            scheduled_params["batch_size"] = batch_size
            for use_edabits in scheduler_config["use_edabits"]:
                scheduled_params["use_edabits"] = use_edabits
                for layer_type in scheduler_config["layer_types_to_replace"]:
                    layer_id_list = []
                    prev_layer_ids = []
                    prev_layer_replacements = []
                    for layer_id in scheduler_config["layer_ids_to_replace"]:
                        layer_id_list = [layer_id]
                        new_replacements_list = []
                        for replace_with in scheduler_config["replace_with"]:
                            # first replace only the single layer
                            replacement = {
                                "layer_indices": layer_id_list.copy(),
                                "layer_to_replace": layer_type,
                                "replace_with": replace_with,
                            }
                            scheduled_params["layer_replacement"] = [replacement]
                            print("")
                            print(f"outer loop: {scheduled_params}")
                            if not dry_run:
                                params_fp, timestamp = create_params_file(
                                    scheduled_params
                                )
                                start_runner(timestamp, params_fp, input_fp)
                            new_replacements_list.append([replacement])
                            new_prev_replacements = []
                            # this inner loop tests all permutations with previously scheduled layer ids and the current layer id
                            for prev_replacements in prev_layer_replacements:
                                # use deepcopy to prevent side effects from references
                                new_prev_replacements = copy.deepcopy(prev_replacements)
                                added_flag = False
                                for l_type in new_prev_replacements:
                                    # add new layer ID to existing IDs list if replace_with layer type matches
                                    if l_type["replace_with"] == replace_with:
                                        l_type["layer_indices"].append(layer_id)
                                        added_flag = True
                                # append new replacement object if the replace_with layer type is not already in prev_replacements
                                if not added_flag:
                                    new_prev_replacements.append(replacement)
                                scheduled_params["layer_replacement"] = (
                                    new_prev_replacements
                                )
                                print(f"inner loop: {scheduled_params}")
                                if not dry_run:
                                    params_fp, timestamp = create_params_file(
                                        scheduled_params
                                    )
                                    start_runner(timestamp, params_fp, input_fp)
                                new_replacements_list.append(new_prev_replacements)
                        prev_layer_replacements += new_replacements_list
                        print(
                            f"updated prev_layer_replacements: {prev_layer_replacements}"
                        )
                        prev_layer_ids += layer_id_list


def create_params_file(scheduled_params: dict):
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    params_file_path = (
        f"/bench_data/thesis_lenet5/scheduler/{timestamp}_scheduled_params.json"
    )
    print(f"Writing scheduled params {scheduled_params} to file '{params_file_path}'")
    with open(params_file_path, "w") as fp:
        json.dump(scheduled_params, fp)
    return params_file_path, timestamp


def start_runner(timestamp: str, params_fp: str, input_fp: str):
    output_fp = f"/bench_data/thesis_lenet5/output/{timestamp}-out.json"
    env = {
        "MPCBR_SETTINGS_LOG_CONFIG_LOCATION": "runtime_configs/mpcbenchrunner_logconfig.yaml",
        "MPCBR_SETTINGS_BENCHMARK_DATA_DIR": "/bench_data/",
        "PYTHONUNBUFFERED": "1",
    }
    with subprocess.Popen(
        [
            "./mpcbenchrunner/bin/python",
            "../mpcbenchrunner/mpcbenchrunner/runner.py",
            input_fp,
            output_fp,
            timestamp,
            params_fp,
        ],
        env=env,
        cwd="./EncryptedMachineBenchmarks/experiments/",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    ) as p:
        output_fp = "".join([print(buf, end="") or buf for buf in p.stdout])


if __name__ == "__main__":
    schedule_runs(
        "./SMPC_ML_StaticScheduler/scheduler_search_space.json",
        "../../SMPC_ML_StaticScheduler/runner_input_config.json",
        False,
    )
