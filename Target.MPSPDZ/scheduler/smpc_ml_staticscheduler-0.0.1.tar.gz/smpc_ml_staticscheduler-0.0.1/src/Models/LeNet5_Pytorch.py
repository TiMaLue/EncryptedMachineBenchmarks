from torch import nn, flatten
from torch.nn import functional as F


class LeNet5Pytorch(nn.Module):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.conv1 = nn.Conv2d(1, 6, kernel_size=(5, 5), stride=1, padding=2)
        self.pool1 = nn.AvgPool2d(2, stride=2)
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)
        self.pool2 = nn.AvgPool2d(2, stride=2)
        self.fc1 = nn.Linear(400, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)
        self.model_name = "LeNet5_Pytorch"

    def forward(self, input):
        c1 = F.sigmoid(self.conv1(input))
        p1 = self.pool1(c1)
        c2 = F.sigmoid(self.conv2(p1))
        p2 = self.pool2(c2)
        flat_p2 = flatten(p2, start_dim=1)
        f1 = F.sigmoid(self.fc1(flat_p2))
        f2 = F.sigmoid(self.fc2(f1))
        f3 = self.fc3(f2)
        return f3
