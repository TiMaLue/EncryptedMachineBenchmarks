import numpy as np
import configparser
from pathlib import Path

from torchvision.datasets import MNIST
from torchvision import transforms

# load config
config = configparser.ConfigParser()
config_path = Path.cwd().joinpath("config.ini")
print(f"Reading config: {config_path}")
config.read(config_path)
# data preprocessing
ds = MNIST(
    root=config["Dataset"]["RootDir"],
    train=False,
    download=True,
    transform=transforms.ToTensor(),
)
print(ds)
test_npy = ds.data.numpy()
# print(test_npy.shape)
test_labels_npy = ds.targets.numpy()
# print(test_labels_npy.shape)
ds_path = Path("/bench_data/thesis_lenet5/datasets")
if not ds_path.exists():
    ds_path.mkdir(parents=True)
np.save(ds_path.joinpath("test.npy"), test_npy)
np.save(ds_path.joinpath("test_labels.npy"), test_labels_npy)
