import numpy as np
import configparser

from torchvision.datasets import MNIST
from torchvision import transforms

# load config
config = configparser.ConfigParser()
config.read("../config.ini")
# data preprocessing
ds = MNIST(
    root=config["Dataset"]["RootDir"],
    train=False,
    download=True,
    transform=transforms.ToTensor(),
)
print(ds)
test_npy = ds.data.numpy()
print(test_npy.shape)
test_labels_npy = ds.targets.numpy()
print(test_labels_npy.shape)

np.save("../datasets/test.npy", test_npy)
np.save("../datasets/test_labels.npy", test_labels_npy)
