import configparser

import torch
from torchvision import transforms
from torchvision.datasets import MNIST
from torch.utils.data import Subset, Dataset
import numpy as np

from Models.LeNet5 import LeNet5_MPSPDZ as LeNet5

config = configparser.ConfigParser()
config.read("../config.ini")
config["Models"]["SaveDir"]
device = "cpu"  #'cuda' if torch.cuda.is_available() else "cpu"
print(device)
batchsize = 32
dataset_size = 32

# load model architecture
lenet = LeNet5()
print(lenet)
model_save_path = "".join(
    [config["Models"]["SaveDir"], lenet.model_name, config["Models"]["Postfix"]]
)

# load model weights
print(f"Loading model: {model_save_path}")
lenet.load_state_dict(torch.load(model_save_path, weights_only=True))
transform = transforms.ToTensor()

# prepare test data
data_dir = config["Dataset"]["RootDir"]
print(f"Using dataset from: {data_dir}")
test_data = MNIST(
    root=data_dir,
    train=False,
    download=True,
    transform=transform,
)

indices = np.arange(dataset_size)
partial_ds: Subset[Dataset[MNIST]] = Subset(test_data, indices)
partial_samples = test_data.data[indices]
partial_labels = test_data.targets[indices]
print(f"Partial samples: {partial_samples}")
print(f"Partial labels: {partial_labels}")

test_loader = torch.utils.data.DataLoader(
    partial_ds, batch_size=batchsize, shuffle=False
)

# test loop
correct = 0
total = 0
lenet.to(device)

with torch.no_grad():
    for data in test_loader:
        inputs, labels = data
        labels = labels.to(device)
        outputs = lenet(inputs.to(device))
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print(f"Accuracy on {total} predictions: {correct / total}")
