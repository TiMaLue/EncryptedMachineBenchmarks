from math import e

#########################################
#        MP-SPDZ implementations        #
#########################################
# these two are based on https://arxiv.org/pdf/2002.04344
# same as in MP-SPDZ
def aby3_sigmoid(x: int | float):
    if x < -0.5:
        return 0
    if x >= 0.5:
        return 1
    return x + 0.5

def five_piece_sigmoid(x: int | float):
    if x < -5:
        return 10 ** -4
    if x <= -2.5:
        return 0.02776 * x + 0.145
    if x <= 2.5:
        return 0.17 * x + 0.5
    if x < 5:
        return 0.02776 * x + 0.85498
    return 1 - 10 ** -4