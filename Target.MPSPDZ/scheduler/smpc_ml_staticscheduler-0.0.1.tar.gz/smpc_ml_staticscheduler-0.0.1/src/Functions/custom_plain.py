from math import e

#########################################
#  Experimental custom implementations  #
#########################################
# custom mix of the 3-piece and 5-piece spline, adding new interval [-2.5, 0.5]
def mixed_sigmoid(x: int | float):
    if x < -5:
        return 10 ** -4
    if x <= -2.5:
        return 0.02776 * x + 0.145
    #if x < -0.5:
    #    return 0
    if x <= 0.5:
        return x + 0.5
    if x <= 2.5:
        return 0.17 * x + 0.5
    if x < 5:
        return 0.02776 * x + 0.85498
    return 1 - 10 ** -4

def default_n_exp(x: int | float):
    return e ** (-x)

def default_tanh(x: int | float):
    return (e ** x - default_n_exp(x)) / (e ** x + default_n_exp(x))