from math import e
from custom_plain import default_n_exp

#########################################
#         SIRNN implementations         #
#########################################
def sirnn_neg_exponential(x: int | float):
    # TODO: use actual SIRNN implementation
    return default_n_exp(x)

def sirnn_sigmoid(x: int | float):
    if x == 0:
        return 0.5
    if x > 0:
        return 1 / (1 + sirnn_neg_exponential(x))
    if x < 0:
        nExp = sirnn_neg_exponential(-x)
        return nExp * (1 / (1 + nExp))

def sirnn_tanh(x: int | float):
    return 2 * sirnn_sigmoid(2 * x) - 1