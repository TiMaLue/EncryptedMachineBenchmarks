import configparser

import torch
from torchvision.datasets import MNIST

import numpy as np
from Models.LeNet5 import LeNet5_ReLU

# load config
config = configparser.ConfigParser()
config.read("../config.ini")
# data preprocessing
ds = MNIST(root=config["Dataset"]["RootDir"], train=False, download=True)
print(ds)
np_data = ds.data.numpy()
print(np_data.shape)
np.save("../datasets/test.npy", np_data)
np_labels = ds.targets
print(np_labels.shape)
np.save("../datasets/test_labels.npy", np_data)
