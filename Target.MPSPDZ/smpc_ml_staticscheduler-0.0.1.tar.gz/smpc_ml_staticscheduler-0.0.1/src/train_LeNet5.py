# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: hydrogen
#       format_version: '1.3'
#       jupytext_version: 1.17.0
#   kernelspec:
#     display_name: Python (thesis)
#     language: python
#     name: thesis
# ---

# %%
import torch
from torch import nn
from torchvision.datasets import MNIST
from torch.nn import functional as F
from torchvision import transforms
from Models.LeNet5 import LeNet5_ReLU
import configparser

# %%
config = configparser.ConfigParser()
config.read("../config.ini")
config["Models"]["SaveDir"]


# %%
device =  'cuda' if torch.cuda.is_available() else "cpu"
print(device)

# %%
lenet = LeNet5_ReLU()
print(lenet)

# %%
print(type(lenet))
lenet(torch.randn(1, 1, 28, 28))

# %%
learning_rate = 0.001
batchsize = 32
epochs = 3
workers = 1
optimizer = torch.optim.Adam(lenet.parameters(), lr=learning_rate)
criterion = nn.CrossEntropyLoss()
model_save_path = "".join([config["Models"]["SaveDir"], lenet.model_name, config["Models"]["Postfix"]])

transform = transforms.ToTensor()
training_data = MNIST(root='/data/Programmierung/Masterthesis/Datasets', train=True, download=True, transform=transform)
train_loader = torch.utils.data.DataLoader(training_data, batch_size=batchsize, shuffle=True)
test_data = MNIST(root='/data/Programmierung/Masterthesis/Datasets', train=False, download=True, transform=transform)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=batchsize, shuffle=True)

print(next(iter(train_loader))[0].shape)

# %%
# training loop
lenet.to(device)
for epoch in range(epochs):
    running_loss = 0.0
    for i, data in enumerate(train_loader):
        inputs, labels = data

        optimizer.zero_grad()
        outputs = lenet(inputs.to(device))
        loss = criterion(outputs, labels.to(device))
        loss.backward()
        optimizer.step()

        # print statistics
        running_loss += loss.item()
        if i % 200 == 199:    # print every 2000 mini-batches
            print(f'[{epoch + 1}, {i + 1:5d}] loss: {running_loss / 2000:.3f}')
            running_loss = 0.0

# %%
if config["Models"].getboolean("saveModel"):
    torch.save(lenet.state_dict(), model_save_path)
    print(f"Model saved to {model_save_path}")
else:
    print("WARNING! Model was not saved as SaveModel is false!")

# %%
# try:
#     lenet
# except NameError:
#     lenet = LeNet5()
#     lenet.load_state_dict(torch.load(SAVE_PATH, weights_only=True))

# test loop
correct = 0
total = 0
lenet.to(device)

with torch.no_grad():
    for data in test_loader:
        inputs, labels = data
        labels = labels.to(device)
        outputs = lenet(inputs.to(device))
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print(f'Accuracy on {total} predictions: {correct / total}')
