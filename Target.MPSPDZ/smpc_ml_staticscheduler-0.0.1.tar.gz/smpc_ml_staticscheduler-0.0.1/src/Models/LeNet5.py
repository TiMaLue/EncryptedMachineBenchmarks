from torch import nn


class LeNet5(nn.Sequential):
    def __init__(self, *args, **kwargs):
        super().__init__(
            nn.Conv2d(1, 6, kernel_size=(5, 5), stride=1, padding=2),
            nn.Sigmoid(),
            nn.AvgPool2d(2, stride=2),
            nn.Conv2d(6, 16, kernel_size=5),
            nn.Sigmoid(),
            nn.AvgPool2d(2, stride=2),
            nn.Flatten(),
            nn.Linear(400, 120),
            nn.Linear(120, 84),
            nn.Linear(84, 10),
        )
        self.model_name = "LeNet5"


class LeNet5_ReLU(nn.Sequential):
    def __init__(self, *args, **kwargs):
        super().__init__(
            nn.Conv2d(1, 6, kernel_size=(5, 5), stride=1, padding=2),
            nn.ReLU(),
            nn.AvgPool2d(2, stride=2),
            nn.Conv2d(6, 16, kernel_size=5),
            nn.ReLU(),
            nn.AvgPool2d(2, stride=2),
            nn.Flatten(),
            nn.Linear(400, 120),
            nn.Linear(120, 84),
            nn.Linear(84, 10),
        )
        self.model_name = "LeNet5_ReLU"
